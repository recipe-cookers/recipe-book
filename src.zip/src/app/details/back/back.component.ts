import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'details-back',
  templateUrl: './back.component.html',
  styleUrls: ['./back.component.scss']
})
export class DetailsBackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
