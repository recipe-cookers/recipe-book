import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ingridients-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class IngridientsFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
