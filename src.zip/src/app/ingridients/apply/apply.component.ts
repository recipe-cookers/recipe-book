import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ingridients-apply',
  templateUrl: './apply.component.html',
  styleUrls: ['./apply.component.scss']
})
export class IngridientsApplyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
