import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ingridients-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class IngridientsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
