import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ingridients-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class IngridientsItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
