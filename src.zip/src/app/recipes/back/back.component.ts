import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'recipe-back',
  templateUrl: './back.component.html',
  styleUrls: ['./back.component.scss']
})
export class RecipeBackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
