import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'recipe-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class ResipeItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
